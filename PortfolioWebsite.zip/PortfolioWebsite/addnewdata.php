<form name="submit-to-google-sheet" action="code.php" method="POST">
    <input type="text" name="Name" placeholder="Your Name" required />
    <input type="email" name="email" placeholder="Your Email" required />
    <input type="pno" name="pno" placeholder="Your phone number" required />
    <textarea name="message" rows="6" placeholder="Your Message"></textarea>
    <button type ="submit" name="save_contact">Submit</button>
</form>